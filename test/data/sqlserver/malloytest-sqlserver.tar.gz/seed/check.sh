#!/usr/bin/env bash

DIR="$(dirname "$0")"

echo "→ Scanning all .tsv in $DIR …"
shopt -s nullglob
for f in "$DIR"/*.tsv; do
  echo
  echo "File: $f"

  # 1) UTF‑8 BOM?
  if head -c3 "$f" | grep -q $'\xEF\xBB\xBF'; then
    echo "  [BOM]   UTF‑8 BOM present"
  fi

  # 2) CRLF line endings?
  if grep -q $'\r' "$f"; then
    echo "  [CRLF]  Found CR characters (CRLF endings)"
  fi

  # 3) Inconsistent column counts?
  counts=$(awk -F'\t' '{print NF}' "$f" | sort -u)
  if [[ $(echo "$counts" | wc -l) -gt 1 ]]; then
    echo "  [COLS]  Inconsistent field counts: $counts"
  fi

  # 4) Trailing tabs or spaces?
  if grep -qP '\t$' "$f"; then
    echo "  [TRAIL] Trailing tab(s) on some lines"
  fi
  if grep -qP ' $' "$f"; then
    echo "  [TRAIL] Trailing space(s) on some lines"
  fi

  # 5) Non‑printable/control chars?
  if grep -qP '[\x00-\x08\x0B\x0C\x0E-\x1F]' "$f"; then
    echo "  [CTRL]  Embedded non‑printable/control characters"
  fi
done

echo
echo "→ Done."